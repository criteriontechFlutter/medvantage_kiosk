import 'dart:typed_data';
import 'package:digi_doctor/AppManager/app_color.dart';
import 'package:digi_doctor/AppManager/my_text_theme.dart';
import 'package:digi_doctor/Pages/Dashboard/NearestHospital/DataModal/nearesthospital_controller.dart';
import 'package:digi_doctor/Pages/Dashboard/NearestHospital/DataModal/nearesthospital_modal.dart';
import 'package:digi_doctor/Pages/Dashboard/NearestHospital/DataModal/src/nearhospital_details_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_place/google_place.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../AppManager/app_util.dart';
import 'dart:ui' as ui;
import '../../../../AppManager/widgets/common_widgets.dart';

class NearestHospital extends StatefulWidget {
  const NearestHospital({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<NearestHospital> createState() => _NearestHospitalState();
}

class _NearestHospitalState extends State<NearestHospital> {
  NearestHospitalModal modal = NearestHospitalModal();
  final Map<String, Marker> _markers = {};
  List<SearchResult> hospitals = [];
  Position? myPosition;

  Future<Position> _determinePosition() async {
//here my code
    bool serviceEnabled;
    if (await Permission.location.serviceStatus.isEnabled) {
      serviceEnabled = true;

      print("hhhhhhhhhhhhh   Location Service Enabled");
    } else {
      serviceEnabled = false;
      print("hhhhhhhhhhhhh   Location Service disabled");
    }
    var status = await Permission.location.status;
    if (status.isGranted) {
      serviceEnabled = true;
    } else if (status.isDenied) {
      Map<Permission, PermissionStatus> status =
          await [Permission.location].request();
    }
    if (await Permission.location.isPermanentlyDenied) {
      openAppSettings();
    }
    //end my code
    return await Geolocator.getCurrentPosition();
  }

  Future<Uint8List> getBytesFromAsset(
      {required String path, required int width}) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(
      data.buffer.asUint8List(),
      targetWidth: width,
      targetHeight: 60,
    );
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!
        .buffer
        .asUint8List();
  }

  // getDetails(String addressId) async {
  //   print(addressId);
  //   var googlePlace = GooglePlace("AIzaSyBiCc5Juc52C8oAvuqo_y2rCQh6VU_802Q");
  //   DetailsResponse? result = await googlePlace.details
  //       .get(addressId, fields: "name,rating,formatted_phone_number");
  //   if (result != null) {
  //     print("details: " + result.status.toString());
  //     print("--------- " + result.result!.adrAddress.toString());
  //   }
  //   print(result?.result!.formattedPhoneNumber.toString());
  // }

  void onMapCreatedNew(GoogleMapController controller) {
    modal.controller.mapController = controller;
    modal.controller.mapController.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
            target: LatLng(myPosition!.latitude, myPosition!.longitude),
            zoom: 15.5)));
    setState(() {});
  }

  void _incrementCounter() async {
    modal.controller.updateShowNoData = false;
    myPosition = await _determinePosition();
    modal.controller.mapController.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
            target: LatLng(myPosition!.latitude, myPosition!.longitude),
            zoom: 14.5)));
    final Uint8List customMarker = await getBytesFromAsset(
      path: "assets/hospital-locater.png",
      width: 38,
    );

    setState(() {});
    var googlePlace = GooglePlace("AIzaSyBiCc5Juc52C8oAvuqo_y2rCQh6VU_802Q");
    var result = await googlePlace.search.getNearBySearch(
        Location(lat: myPosition!.latitude, lng: myPosition!.longitude), 1500,
        type: "hospital", keyword: "hospital");
    NearBySearchResponse? response = result;
    if (result != null) {
      hospitals = response!.results!;
      //  print(hospitals[0].geometry.toString());
      for (var i = 0; i < hospitals.length; i++) {
        SearchResult hospital = hospitals[i];
        print(hospital.geometry!.location!.lat);
        final marker = Marker(
          icon: BitmapDescriptor.fromBytes(customMarker),
          markerId: MarkerId(hospital.name.toString()),
          position: LatLng(hospital.geometry!.location!.lat!,
              hospital.geometry!.location!.lng!),
          infoWindow: InfoWindow(
            title: hospital.id,
            snippet: hospital.formattedAddress,
          ),
        );
        _markers[hospital.name.toString()] = marker;
      }
      setState(() {});
      print("resulttttttttttttttttttttt: " + result.status.toString());
      print("resulttttttttttttttttttttt: " + result.results.toString());
    }

    modal.controller.updateShowNoData = true;
  }

  @override
  void dispose() {
    modal.controller.mapController.dispose();
    super.dispose();
    _incrementCounter();
  }

  @override
  void initState() {
    super.initState();
    _incrementCounter();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.lightBlue,
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: GetBuilder(
          init: NearestHospitalController(),
          builder: (_) {
            return Center(
                child: Column(children: <Widget>[
              myPosition == null
                  ? Container()
                  : Padding(
                      padding: const EdgeInsets.only(left: 20.0, top: 2),
                      child: Row(
                        children: [
                          Expanded(
                            child:
                                Text("Lat: " + myPosition!.latitude.toString()),
                          ),
                          Expanded(
                            child: Text(
                                "Lon: " + myPosition!.longitude.toString()),
                          ),
                        ],
                      ),
                    ),
              Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    height: 200,
                    width: 350,
                    // color: Colors.blueAccent,
                    child: GoogleMap(
                      myLocationButtonEnabled: true,
                      myLocationEnabled: true,
                      mapToolbarEnabled: true,
                      markers: _markers.values.toSet(),
                      onMapCreated: onMapCreatedNew,
                      initialCameraPosition: CameraPosition(
                        target: LatLng(0, 0), //modal.controller.centerPosition,
                        zoom: 11.5,
                      ),
                    ),
                  )),
              Expanded(
                  child: CommonWidgets().showNoData(
                title: 'Data Not Found',
                show: (modal.controller.getShowNoData && hospitals.isEmpty),
                loaderTitle: 'Loading Data...',
                showLoader:
                    (!modal.controller.getShowNoData && hospitals.isEmpty),
                child: ListView(children: [
                  StaggeredGrid.count(
                      crossAxisCount: 2,
                      mainAxisSpacing: 2,
                      children: List.generate(hospitals.length, (index) {
                        SearchResult hospital = hospitals[index];
                        return Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: InkWell(
                            onTap: () async {
                              App().navigate(
                                  context,
                                  NearHospitalDetails(
                                    hospitalDetail: hospital,
                                  ));
                            },
                            child: Container(
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(5),
                                  color: AppColor.white),
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Center(
                                      child: Image.asset(
                                          'assets/hospital-building.png',
                                          color: AppColor.greyLight
                                              .withOpacity(0.7),
                                          height: 70),
                                    ),
                                    Text(hospital.name.toString(),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: MyTextTheme().smallBCB),
                                    SizedBox(
                                      height: 2,
                                    ),
                                    Text(
                                      hospital.vicinity.toString(),
                                      maxLines: 1,
                                    ),
                                    SizedBox(
                                      height: 5,
                                    ),
                                    InkWell(
                                        onTap: () {
                                          App().navigate(
                                              context,
                                              NearHospitalDetails(
                                                hospitalDetail: hospital,
                                              ));
                                        },
                                        child: Text("Details")),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      })),
                ]),
              )),
            ]));
          }),
    floatingActionButton: SizedBox(
      height: 45,
      child: FloatingActionButton(
      onPressed: (){
        _incrementCounter();
        },
      // backgroundColor: Colors.blue.shade500,
      child:
        Icon(Icons.cached_rounded,size: 30,),
      ),
    )
    );
  }
}
