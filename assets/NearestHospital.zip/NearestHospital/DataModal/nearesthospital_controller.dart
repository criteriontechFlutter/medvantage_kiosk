import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class NearestHospitalController extends GetxController {
  late GoogleMapController mapController;


  RxBool showNoData=false.obs;
  bool get getShowNoData=>(showNoData.value);
  set updateShowNoData(bool val){
    showNoData.value=val;
    update();
  }




  final LatLng centerPosition = const LatLng(45.521563, -122.677433);

  void onMapCreated(GoogleMapController controller) {
  }

  var currentLocation;

  void initState() {
    super.dispose();
    Geolocator.getCurrentPosition().then((CurrentLocation) {
      currentLocation = CurrentLocation;
    });
  }
}
