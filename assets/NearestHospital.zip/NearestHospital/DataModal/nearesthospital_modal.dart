


import 'package:digi_doctor/Pages/Dashboard/NearestHospital/DataModal/nearesthospital_controller.dart';
import 'package:get/get.dart';
import 'package:google_place/google_place.dart';

class NearestHospitalModal{
  NearestHospitalController controller=Get.put(NearestHospitalController());

  getDetails(String addressId) async {
    var googlePlace = GooglePlace("AIzaSyBiCc5Juc52C8oAvuqo_y2rCQh6VU_802Q");
    DetailsResponse? result = await googlePlace.details.get(addressId,
        fields: "name,rating,formatted_phone_number");

    if (result != null) {
      return result.result;
    }
  }
}